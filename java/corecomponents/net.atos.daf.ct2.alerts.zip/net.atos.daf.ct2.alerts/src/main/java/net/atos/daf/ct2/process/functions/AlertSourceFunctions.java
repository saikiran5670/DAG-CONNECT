package net.atos.daf.ct2.process.functions;

import java.io.Serializable;

public class AlertSourceFunctions implements Serializable {
    private static final long serialVersionUID = -5216138635264387584L;
}
